Specification Design Patterns
=============================

Certain patterns often occur in specification files.  This chapter describes
some of these patterns.

```{toctree}
sums.md
partial-apply.md
safe-assum.md
require-invariants.md
```

