Designing Good Specifications
=============================

This chapter describes several methods for thinking systematically about
specifications.

[tutorial]: https://github.com/Certora/Tutorials/tree/master/06.Lesson_ThinkingProperties
[aave-video]: https://www.youtube.com/watch?v=QukwpzHhPL0&t=2185s
[notes]: https://github.com/Certora/Tutorials/tree/master/3DayWorkshop

Method Specifications
---------------------

Variable Changes
----------------

Variable Relationships
----------------------

State-Transition Systems
------------------------

Risk Assessment
---------------

Mathematical Properties
-----------------------


