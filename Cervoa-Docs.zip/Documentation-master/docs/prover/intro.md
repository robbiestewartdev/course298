Introduction
============

This Reference Manual contains detailed and comprehensive information about the
Certora Prover.  The Reference Manual is intended to describe what the Prover
does, in contrast to the {doc}`/docs/user-guide/index` which explains how to
use the Prover to accomplish particular goals.