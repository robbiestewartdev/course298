(white-paper)=
# Certora Technology White Paper

Learn more about Certora's technology from our [White Paper](https://www.certora.com/blog/white-paper).