# CertoraRun Flags

- [disable_auto_cache_key_gen](viewreentrancy)
- [enableStorageAnalysis](sort/fromregtest)
- [files (multiple contracts)](constantproductpool)
- [include_empty_fallback](import)
- [link]
- [loop_iter](https://github.com/Certora/Examples/blob/648b4c3923f948b3150b8346394cc2fd33691ca7/CVLByExample/structs/BankAccounts/certora/conf/runStructs.conf#L10)
- [optimistic_loop](https://github.com/Certora/Examples/blob/648b4c3923f948b3150b8346394cc2fd33691ca7/CVLByExample/structs/BankAccounts/certora/conf/runStructs.conf#L8)
- [rule_sanity](https://github.com/Certora/Examples/blob/648b4c3923f948b3150b8346394cc2fd33691ca7/CVLByExample/structs/BankAccounts/certora/conf/runStructs.conf#L9)
- [multi_assert_check](https://github.com/Certora/Examples/blob/648b4c3923f948b3150b8346394cc2fd33691ca7/CVLByExample/storage/certora/conf/runStorage.conf#L10)
- [smt_groundQuantifiers](sort/fromregtest)
- [solc_allow_path](https://github.com/Certora/Examples/blob/648b4c3923f948b3150b8346394cc2fd33691ca7/CVLByExample/storage/certora/conf/runStorage.conf#L11
)




