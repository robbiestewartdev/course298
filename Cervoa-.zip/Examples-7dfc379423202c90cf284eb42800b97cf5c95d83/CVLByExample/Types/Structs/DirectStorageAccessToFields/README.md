# Direct Storage Access to Structs
This example demonstrate directly accessing Solidity structs fields through CVL

You can run this spec using:
```certoraRun RootStruct.conf```